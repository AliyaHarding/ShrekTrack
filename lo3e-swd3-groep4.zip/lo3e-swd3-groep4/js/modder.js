const splattersContainer = document.querySelector('.splatters');

function createSplatter() {
    const splatter = document.createElement('div');
    splatter.classList.add('splatter');
    splatter.style.left = `${Math.random() * 100}%`;
    splatter.style.animationDuration = `${Math.random() * 2 + 1}s`;
    splattersContainer.appendChild(splatter);

    setTimeout(() => {
        splatter.remove();
    }, 2000);
}

setInterval(createSplatter, 300);