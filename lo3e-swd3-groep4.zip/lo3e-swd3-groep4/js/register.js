document.addEventListener("DOMContentLoaded", function () {
    const formContainer = document.querySelector(".form-container");

    formContainer.addEventListener("mouseenter", () => {
        formContainer.style.transform = "rotate(5deg) scale(1.05)";
    });

    formContainer.addEventListener("mouseleave", () => {
        formContainer.style.transform = "rotate(0deg) scale(1)";
    });

    const submitButton = document.querySelector("button");
    submitButton.addEventListener("click", () => {
        submitButton.style.backgroundColor = "#FF4500"; // OrangeRed
        submitButton.innerText = "Registreren...";
        setTimeout(() => {
            submitButton.innerText = "Registreren";
        }, 1000);
    });

    const quotes = [
        "Wat ben jij een ongelooflijke ezel!",
        "Swamp is life!",
        "Ogres zijn als uien...",
        "Welkom in mijn swamp!"
    ];
    const quoteElement = document.querySelector(".shrek-quote p");
    let quoteIndex = 0;

    setInterval(() => {
        quoteElement.textContent = quotes[quoteIndex];
        quoteIndex = (quoteIndex + 1) % quotes.length;
    }, 5000);
});