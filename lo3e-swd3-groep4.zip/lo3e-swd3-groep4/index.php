<!DOCTYPE html>
<html lang="nl">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Welkom bij Shrek's Activiteiten Planner</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        /* Algemene stijlen */
        body {
            font-family: 'Comic Sans MS', cursive, sans-serif;
            background: linear-gradient(135deg, #88AE5F, #6c8a4d); /* Groene gradient */
            color: white;
            margin: 0;
            padding: 0;
            text-align: center;
            overflow-x: hidden;
        }

        header {
            background-color: #556B2F; /* Donkerder groen */
            padding: 20px;
            color: white;
            font-size: 24px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }

        .container {
            padding: 40px 20px;
            max-width: 800px;
            margin: 0 auto;
            background-color: rgba(255, 255, 255, 0.9); /* Witte achtergrond met transparantie */
            border-radius: 15px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            margin-top: 20px;
        }

        h1 {
            font-size: 48px;
            color: #556B2F; /* Donkerder groen */
            animation: fadeIn 2s ease-in-out;
        }

        p {
            font-size: 20px;
            color: #555;
            animation: slideUp 1.5s ease-in-out;
        }

        .btn {
            background-color: #556B2F; /* Donkerder groen */
            color: white;
            padding: 12px 24px;
            border: none;
            border-radius: 5px;
            font-size: 18px;
            cursor: pointer;
            margin: 10px;
            transition: background-color 0.3s ease, transform 0.3s ease;
        }

        .btn:hover {
            background-color: #88AE5F; /* Lichter groen */
            transform: scale(1.05);
        }

        .shrek-img {
            width: 200px;
            margin-top: 20px;
            animation: bounce 2s infinite;
        }

        .icons {
            margin-top: 30px;
            display: flex;
            justify-content: center;
            gap: 20px;
            animation: fadeIn 2s ease-in-out;
        }

        .icons i {
            font-size: 40px;
            color: #556B2F; /* Donkerder groen */
            transition: transform 0.3s ease;
        }

        .icons i:hover {
            transform: scale(1.2);
        }

        footer {
            background-color: #556B2F; /* Donkerder groen */
            padding: 10px;
            color: white;
            position: fixed;
            bottom: 0;
            width: 100%;
            box-shadow: 0 -4px 6px rgba(0, 0, 0, 0.1);
        }

        /* Animaties */
        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }

        @keyframes slideUp {
            from { transform: translateY(20px); opacity: 0; }
            to { transform: translateY(0); opacity: 1; }
        }

        @keyframes bounce {
            0%, 100% { transform: translateY(0); }
            50% { transform: translateY(-10px); }
        }

        /* Extra Shrek-stijl elementen */
        .moeras-text {
            font-size: 24px;
            color: #88AE5F;
            font-weight: bold;
            margin-top: 10px;
        }

        .moeras-text span {
            display: inline-block;
            animation: swing 2s infinite;
        }

        @keyframes swing {
            0%, 100% { transform: rotate(-5deg); }
            50% { transform: rotate(5deg); }
        }
    </style>
</head>

<body>
    <header>
      <?php
      include 'includes/header.php';
      ?>
    </header>

    <div class="container">
    <video class="shrek-video" autoplay loop muted>
            <source src="img/shrek donkey cringe staring meme.mp4" type="video/mp4">
        </video>
        <h1>Welkom in de Moeras!</h1>
        <p>Plan je activiteiten met Shrek en zijn vrienden. Log in om te beginnen!</p>

        <div class="moeras-text">
            <span>🟢</span> Ontdek de magie van het moeras! <span>🟢</span>
        </div>

        <div class="icons">
            <i class="fas fa-dragon" title="Draak"></i>
            <i class="fas fa-frog" title="Kikker"></i>
            <i class="fas fa-tree" title="Boom"></i>
            <i class="fas fa-horse" title="Ezel"></i>
            <i class="fas fa-castle" title="Kasteel"></i>
        </div>

        <button class="btn" onclick="window.location.href='login.php'">Log In</button>
        <button class="btn" onclick="window.location.href='signup.php'">Sign Up</button>
        <button class="btn" onclick="logout()">Log Out</button>
    </div>

    <script>
        function logout() {
            alert("Je bent uitgelogd!");
        }
    </script>
</body>

</html>



