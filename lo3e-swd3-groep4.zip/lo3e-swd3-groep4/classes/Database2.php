<?php
class Database2{
    private $host = 'db';
    private $dbname = 'feestje';
    private $username = 'root';
    private $password = 'root';
    private $conn;

    public function connect() {
        try {
            $this->conn = new PDO(
                "mysql:host=$this->host;dbname=$this->dbname", 
                $this->username, 
                $this->password
            );
            $this->conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            echo "Connected successfully with PDO";
            return $this->conn;
        } catch(PDOException $e) {
            die("PDO Connection failed: " . $e->getMessage());
        }
    }
}

?>