<?php 
// dependancy
class Event {
    public $title;
    public $description;
    public $date;
    public $eventType;

    private $pdo;

    public function __construct(Database $db) {
        $this->pdo = $db->getConnection();
    }

    public function addEvent($event) {
        $title = $event['title'] ?? '';
        $description = $event['description'] ?? '';
        $date = $event['date'] ?? '';
        $eventType = $event['eventType'] ?? '';

        $this->title = htmlspecialchars($title);
        $this->description = htmlspecialchars($description);
        $this->date = htmlspecialchars($date);
        $this->eventType = htmlspecialchars($eventType);

        $stmt = $this->pdo->prepare("INSERT INTO event (title, description, date, eventType) VALUES (:title, :description, :date, :eventType)");
        $stmt->bindParam(':title', $this->title);
        $stmt->bindParam(':description', $this->description);
        $stmt->bindParam(':date', $this->date);
        $stmt->bindParam(':eventType', $this->eventType);

        if ($stmt->execute()) {
            return true;
        } else {
            echo "Error inserting event: ";
            print_r($stmt->errorInfo()); // Display error messages
            return false;
        }
    }
}
?>