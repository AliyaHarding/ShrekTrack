<?php
// generalisatie
class Event2 extends Database2{
    public function deleteEvent($eventId) {
        $conn = $this->connect();
        $stmt = $conn->prepare("DELETE FROM events WHERE id = ?");
        return $stmt->execute([$eventId]);
    }
}
?>