<?php
require_once 'config.php';

abstract class WeerService {
    protected $apiKey;
    protected $baseUrl;

    public function __construct($apiKey) {
        $this->apiKey = $apiKey;
    }

    abstract public function haalWeerOp($locatie);
}

class OpenWeatherService extends WeerService {
    protected $baseUrl = "https://api.openweathermap.org/data/2.5/forecast";

    public function haalWeerOp($locatie) {
        $url = "{$this->baseUrl}?q={$locatie}&units=metric&appid={$this->apiKey}";
        $response = file_get_contents($url);
        return json_decode($response, true);
    }
}

$weerService = new OpenWeatherService(API_KEY);
header('Content-Type: application/json');
echo json_encode($weerService->haalWeerOp("Leiden"));
?>
