<?php
define("API_KEY", "563c0cb93aa9aec0e7c075252108353e");
?>
