class Fetcher {
    static async fetchData(url) {
        try {
            let response = await fetch(url);
            return await response.json();
        } catch (error) {
            console.error('Error fetching data:', error);
        }
    }
}

// Quotes 
class Quote extends Fetcher {
    static async fetchQuotes() {
        const data = await this.fetchData('msgData.json');
        if (!data) return;

        const template = document.getElementById('quote-template');
        const quotesList = document.getElementById('quotes-list');

        data.quotes.forEach(item => {
            const clone = template.content.cloneNode(true);
            clone.querySelector('.quote').textContent = `"${item.quote}"`;
            clone.querySelector('.author').textContent = `- ${item.author}`;
            quotesList.appendChild(clone);
        });
    }
}

// Jokes
class Joke extends Fetcher {
    static async fetchJoke() {
        const data = await this.fetchData('https://api.chucknorris.io/jokes/random');
        if (data) {
            document.getElementById('joke').textContent = data.value;
        }
    }
}

Quote.fetchQuotes();
Joke.fetchJoke();