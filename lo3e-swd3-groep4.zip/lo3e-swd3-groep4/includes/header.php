<?php
?>
<!DOCTYPE html>
<html lang="nl">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mijn Website</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <style>
        :root {
            --bgColor: #F1F1F2;
            --textColor: #000000;
            --primaryGreen: #A5CC6B;
            --secondaryGreen: #6A9052;
        }

        .header {
            width: 200px;
            height: 100vh;
            background-color: var(--primaryGreen);
            position: fixed;
            left: 0;
            top: 0;
            display: flex;
            flex-direction: column;
            align-items: center;
            padding: 20px 0;
        }

        .logo {
            width: 100px;
            margin-bottom: 30px;
        }

        .nav {
            display: flex;
            flex-direction: column;
            gap: 20px;
            width: 100%;
        }

        .nav-item {
            display: flex;
            align-items: center;
            gap: 10px;
            padding: 10px;
            margin-left: 30px;
            color: var(--textColor);
            text-decoration: none;
            font-size: 18px;
            transition: background 0.3s ease, transform 0.2s ease;
        }

        .nav-item:hover {
            background: var(--secondaryGreen);
            transform: scale(1.05);
        }

        .nav-icon {
            font-size: 24px;
        }

        .button-container {
            margin-top: auto;
            display: flex;
            flex-direction: column;
            gap: 10px;
            padding: 20px;
        }

        .button {
            width: 80%;
            padding: 17px;
            margin-bottom: 40px;
            text-align: center;
            background-color: var(--secondaryGreen);
            color: white;
            text-decoration: none;
            border-radius: 5px;
            transition: background 0.3s;
            font-size: 17px;
        }

        .button:hover {
            background-color: #5a7e44;
        }

        main {
            margin-left: 220px;
            padding: 20px;
            background-color: var(--bgColor);
            color: var(--textColor);
        }

        
    </style>
</head>

<body>
    <header class="header">
        <img src="img/images-Photoroom.png" alt="Logo" class="logo">
        <nav class="nav">
            <a href="#" class="nav-item"><i class="fa-solid fa-house nav-icon"></i>Home</a>
            <a href="#" class="nav-item"><i class="fa-solid fa-info-circle nav-icon"></i>Over Ons</a>
            <a href="#" class="nav-item"><i class="fa-solid fa-cogs nav-icon"></i>Diensten</a>
            <a href="#" class="nav-item"><i class="fa-solid fa-envelope nav-icon"></i>Contact</a>
        </nav>
        <div class="button-container">
            <a href="login.php" class="button">Log In</a>
            <a href="register.php" class="button">Registreer</a>
        </div>
    </header>

    <main>
        <h1>Welkom op mijn ShrekTrack</h1>
       <div class="container">
        <div class="swamp"></div>
        <div class="donkey"></div>
        <h1 class="swamp-text">Dit is mijn Swamp</h1>
    </div>
    </main>
</body>

</html>