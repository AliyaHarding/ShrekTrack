<?php
if (isset($_GET["title"]) && isset($_GET["date"]) && isset($_GET["eventType"]) && isset($_GET["description"])) {
    $title = htmlspecialchars($_GET["title"]);
    $date = htmlspecialchars($_GET["date"]);
    $eventType = htmlspecialchars($_GET["eventType"]);
    $description = htmlspecialchars($_GET["description"]);
} else {
    echo "Invalid event!";
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $title; ?></title>
    <link rel="stylesheet" href="css/formStyle.css" type="text/css">
</head>
<body>
<h2><?php echo $title; ?></h2>
<section class="eventData">
<section class="eventDataInfo">
    <section class="TextSec">
        <p><strong>Date & Time:</strong><br> <?php echo $date; ?></p><br>
        <p><strong>Type:</strong><br> <?php echo $eventType; ?></p><br>
        <p><strong>Description:</strong><br> <?php echo nl2br($description); ?></p>
        <a href="Calendar.php"><— Back to Home</a>
    </section>
</section>
</section>
</body>
</html>
