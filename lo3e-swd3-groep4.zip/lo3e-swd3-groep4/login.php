<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Shrek Login</title>
    <style>
        /* Shrek-thema kleuren */
        :root {
            --swampGreen: #4A7023;
            --mudBrown: #5C4033;
            --ogreYellow: #C3B091;
            --textColor: #fff;
            --buttonColor: #A67C52;
            --buttonHover: #8B5A2B;
        }

        /* Algemene body-styling */
        body {
            background-color: var(--swampGreen);
            font-family: 'Comic Sans MS', cursive, sans-serif;
            color: var(--textColor);
            text-align: center;
            margin: 0;
            padding: 0;
        }

        /* Koptekst-stijl */
        h2 {
            color: var(--ogreYellow);
            text-shadow: 3px 3px var(--mudBrown);
            margin-top: 50px;
            font-size: 2em;
        }

        /* Foutmelding stijl */
        #error-message {
            color: red;
            font-size: 1.2em;
            font-weight: bold;
        }

        /* Formulier styling */
        form {
            display: inline-block;
            background-color: var(--mudBrown);
            padding: 20px;
            border-radius: 15px;
            box-shadow: 5px 5px 15px rgba(0, 0, 0, 0.6);
            margin-top: 20px;
        }

        /* Inputvelden styling */
        input[type="email"], input[type="password"] {
            padding: 10px;
            margin: 10px 0;
            border: 3px solid var(--ogreYellow);
            border-radius: 5px;
            width: 250px;
            font-size: 1em;
            background-color: #fff8dc;
        }

        /* Login knop stijl */
        button {
            background-color: var(--buttonColor);
            color: white;
            padding: 10px 20px;
            border: 3px solid var(--ogreYellow);
            border-radius: 10px;
            font-size: 1.2em;
            cursor: pointer;
            transition: background-color 0.3s ease;
            font-weight: bold;
        }

        button:hover {
            background-color: var(--buttonHover);
        }

        /* Terug naar Homepage knop stijl */
        .home-button {
            display: inline-block;
            margin-top: 20px;
            background-color: var(--buttonColor);
            color: white;
            padding: 10px 20px;
            border: 3px solid var(--ogreYellow);
            border-radius: 10px;
            font-size: 1.2em;
            cursor: pointer;
            transition: background-color 0.3s ease;
            font-weight: bold;
            text-decoration: none;
        }

        .home-button:hover {
            background-color: var(--buttonHover);
        }
    </style>
</head>
<body>
    <h2>Welkom in het Moeras! Log in</h2>
    <p id='error-message'></p>
    <form id="loginForm" method="post">
        <input type="email" name="email" id="email" placeholder="Ezel, vul je e-mail in!" required>
        <br>
        <input type="password" name="password" id="password" placeholder="Niet je moeraswachtwoord vergeten!" required>
        <br>
        <button type="submit">Laat me erin!</button>
    </form>

    <!-- Terug naar Homepage knop -->
    <a href="index.php" class="home-button">Terug naar Homepage</a>

    <script>
        const form = document.getElementById('loginForm');
        const emailInput = document.getElementById('email');
        const passwordInput = document.getElementById('password');
        const errorMessage = document.getElementById('error-message');

        form.addEventListener('submit', function (event) {
            event.preventDefault();

            if (emailInput.value === "" || passwordInput.value === "") {
                errorMessage.textContent = "Ezel! Vul alle velden in.";
            } else {
                form.submit();
            }
        });
    </script>
</body>
</html>