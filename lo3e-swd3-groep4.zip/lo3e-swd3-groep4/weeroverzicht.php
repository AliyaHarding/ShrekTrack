<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Weer App</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        body { font-family: Arial, sans-serif; text-align: center; }
        table { width: 80%; margin: 20px auto; border-collapse: collapse; }
        th, td { border: 1px solid #ddd; padding: 10px; }
        th { background-color: #4CAF50; color: white; }
        canvas { max-width: 80%; margin: 20px auto; }
    </style>
</head>
<body>
    <h1>Weer in Leiden</h1>
    <table>
        <thead>
            <tr>
                <th>Datum</th>
                <th>Temperatuur (°C)</th>
                <th>Weer</th>
            </tr>
        </thead>
        <tbody id="weertabel"></tbody>
    </table>
    <canvas id="weergrafiek"></canvas>

    <script>
        async function haalWeerOp() {
            const response = await fetch('weer.php');
            const data = await response.json();

            const dagen = {};
            data.list.forEach(weer => {
                let datum = weer.dt_txt.split(" ")[0];
                if (!dagen[datum]) dagen[datum] = [];
                dagen[datum].push(weer.main.temp);
            });

            const labels = Object.keys(dagen);
            const temperaturen = labels.map(datum => {
                const tempGemiddeld = dagen[datum].reduce((a, b) => a + b, 0) / dagen[datum].length;
                return tempGemiddeld.toFixed(1);
            });

            vulTabel(labels, temperaturen);
            tekenGrafiek(labels, temperaturen);
        }

        function vulTabel(dagen, temperaturen) {
            const tbody = document.getElementById('weertabel');
            tbody.innerHTML = "";
            dagen.forEach((datum, index) => {
                let rij = `<tr>
                    <td>${datum}</td>
                    <td>${temperaturen[index]}°C</td>
                    <td>🌤️</td>
                </tr>`;
                tbody.innerHTML += rij;
            });
        }

        function tekenGrafiek(labels, temperaturen) {
            new Chart(document.getElementById('weergrafiek'), {
                type: 'line',
                data: {
                    labels: labels,
                    datasets: [{
                        label: 'Gemiddelde temperatuur (°C)',
                        data: temperaturen,
                        borderColor: 'blue',
                        backgroundColor: 'rgba(0, 0, 255, 0.2)',
                        fill: true
                    }]
                },
                options: { responsive: true }
            });
        }

        haalWeerOp();
    </script>
</body>
</html>