<?php
require_once 'autoload.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $db = new Database();
    $user = new User($db);

    $email = $_POST['email'];
    $password = $_POST['password'];

    if ($user->register($email, $password)) {
        echo "<p class='success-message'>Registratie succesvol! Welkom in de swamp!</p>";
    } else {
        echo "<p class='error-message'>Registratie mislukt! Probeer het opnieuw, ogre!</p>";
    }
}
?>

<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registreren in Shrek's Swamp</title>
    <link rel="stylesheet" href="css/register.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css">
</head>
<body>
    <div class="shrek-background">
        <div class="swamp-overlay"></div>
        <div class="form-container animate__animated animate__bounceIn">
            <h2>Registreer een account in Shrek's Swamp</h2>
            <form method="POST">
                <label for="email">E-mail:</label>
                <input type="email" name="email" required placeholder="Voer je e-mail in...">
                <br>
                <label for="password">Wachtwoord:</label>
                <input type="password" name="password" required placeholder="Kies een sterk wachtwoord...">
                <br>
                <button type="submit">Registreren</button>
            </form>
            <div class="shrek-quote">
                <p>"Wat ben jij een ongelooflijke ezel!"</p>
            </div>
        </div>
    </div>
    <script src="js/register.js"></script>
</body>
</html>